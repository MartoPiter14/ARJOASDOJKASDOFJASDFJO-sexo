import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { StyleSheet, Text, View, Button, Image } from 'react-native';

export default function App() {

  const [numero,setNumero] = useState(0)

  let vezVeces = funcVezVeces(numero);



  return (
    
    <View style={styles.container}>
      <Image style={styles.img} source={require('./fondo.jpg')}></Image>
      <Text style={styles.texto}>Has tocado el boton {numero} {vezVeces} </Text>
      <Button style={styles.boton} onPress={()=> setNumero( numero+1 )} title="Tocame"/>
      <StatusBar style="auto" />
    </View>
  );
}

function funcVezVeces(numero){

  if (numero === 1){
    return "vez.";
  }else{
    return "veces.";
  }

}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },

  texto:{

    paddingBottom: 15,
    fontSize: 25,
    color: "grey",

  },
  
  boton: {
    backgroundColor: "#4CAF50",
    border: "none",
    color: "white",
    padding: "15px 32px",
    textAlign: "center",
    textDecoration: "none",
    display: "inline-block",
    fontSize: "16px",
  },

  img: { 
    zIndex:-1,
    position:"fixed",
    width: "100%",
    height:"100%"
  }
  
});
